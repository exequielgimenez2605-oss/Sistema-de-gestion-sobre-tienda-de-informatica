#ifndef CLSFUNCIONESREPORTE_H_INCLUDED
#define CLSFUNCIONESREPORTE_H_INCLUDED

void recaudacionPorCliente();
void MesConMenorVenta2025();
void mayorVentaAnios();
void MayorFacturacion2024y2025();
void ProductoMasVendidoEnLosUltimos2();
void MontoTotalVendidoProductoPorCliente();
void PromedioProductosPorVenta();


#endif // CLSFUNCIONESREPORTE_H_INCLUDED
