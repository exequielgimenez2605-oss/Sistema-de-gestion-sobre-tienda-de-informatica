#include <iostream>
#include "menuPrincipal.h"

using namespace std;

int main()
{
    setlocale(LC_ALL,"spanish");
    menuPrincipal();

    return 0;
}
