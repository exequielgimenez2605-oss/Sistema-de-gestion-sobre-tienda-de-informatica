#ifndef REPORTES_H_INCLUDED
#define REPORTES_H_INCLUDED

void mayorVentaAno();

#endif // REPORTES_H_INCLUDED
