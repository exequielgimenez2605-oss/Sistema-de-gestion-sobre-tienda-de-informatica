#ifndef CARGARCADENA_H_INCLUDED
#define CARGARCADENA_H_INCLUDED

void cargarCadena(char *, int);

#endif // CARGARCADENA_H_INCLUDED

