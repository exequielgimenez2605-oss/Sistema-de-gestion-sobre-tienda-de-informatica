#ifndef FUNCIONESVENTA_H_INCLUDED
#define FUNCIONESVENTA_H_INCLUDED

void registrarVenta();
void listarVentas();
void buscarVenta();
void darDeBajaVenta();
void listarVentasBaja();
void DarAltaVenta();


#endif // FUNCIONESVENTA_H_INCLUDED
