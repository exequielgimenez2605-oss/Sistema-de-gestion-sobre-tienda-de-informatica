#ifndef FUNCIONESDETALLE_H_INCLUDED
#define FUNCIONESDETALLE_H_INCLUDED

void registrarDetalle();
void listarDetalles();
void buscarDetalle();
void darDeBajaDetalle();
void modificarDetalle();

void listarDetallesBaja();
void DarAltaDetalle();


#endif // FUNCIONESDETALLE_H_INCLUDED
