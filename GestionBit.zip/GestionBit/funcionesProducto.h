#ifndef FUNCIONESPRODUCTO_H_INCLUDED
#define FUNCIONESPRODUCTO_H_INCLUDED

void registrarProducto();
void listarProductos();
void buscarProducto();
void darDeBajaProducto();
void modificarProducto();

void listarProductoBaja();
void darAltaProducto();

#endif // FUNCIONESPRODUCTO_H_INCLUDED
