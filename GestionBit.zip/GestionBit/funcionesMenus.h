#ifndef FUNCIONESMENUS_H_INCLUDED
#define FUNCIONESMENUS_H_INCLUDED

void menuClientes();
void menuVentas();
void menuProductos();
void menuDetalles();
void menuReportes();

#endif // FUNCIONESMENUS_H_INCLUDED
