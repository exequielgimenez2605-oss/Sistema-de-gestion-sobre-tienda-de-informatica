#ifndef FUNCIONESCLIENTE_H_INCLUDED
#define FUNCIONESCLIENTE_H_INCLUDED


void registrarCliente();
void listarClientes();
void buscarCliente();
void darDeBajaCliente();
void modificarCliente();

void listarClientesBaja();
void darAltaClientes();



#endif // FUNCIONESCLIENTE_H_INCLUDED
